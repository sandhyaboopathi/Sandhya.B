document.getElementById("contactForm").addEventListener("submit", function(e) {
    e.preventDefault();

    // Optional: Clear the form or display a message
    document.getElementById("formMessage").textContent = "Thank you for reaching out!";
    this.reset();
});
